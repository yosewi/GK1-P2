using System.Numerics;

namespace BezierSurfaces.Features.Lighting
{
    // Punktowe źródło światła. Stoi w układzie sceny, więc nie obraca się razem z powierzchniami.
    public sealed class LightSource
    {
        // Wysokość startowa - tę samą pokazuje suwak po uruchomieniu programu.
        public const int DefaultHeight = 500;

        // Położenie światła. Na starcie nad środkiem sceny.
        public Vector3 Position { get; private set; } = new Vector3(0, 0, DefaultHeight);

        // Zmienia tylko wysokość z, x i y zostają bez zmian.
        public void SetHeight(float z)
        {
            Position = new Vector3(Position.X, Position.Y, z);
        }
    }
}
